package junit.test;
import java.util.Scanner;


/**
 *
 * @author Gulshan yasmeen
 */
public class JUnitTest {

    /**
     * @param args the command line arguments
     */
      public static void main(String[] args) {
        // TODO code application logic here
    }
    public static int[][] multiply(){
         int m;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the base of square matrix");
        m=input.nextInt();
        int [][] a=new int[m][m];
          int [][] b=new int[m][m];
            int [][] c=new int[m][m];
         
         System.out.print("Enter the elements of first matrix\n");
          for(int i=0;i<m;i++){
              for(int j=0;j<m;j++){
                  a[i][j]=input.nextInt();
              }
        
    }
         System.out.print("Enter the elements of second matrix\n");  
          for(int i=0;i<m;i++){
              for(int j=0;j<m;j++){
                  b[i][j]=input.nextInt();
              }
        
    }
          System.out.print("multiplying the entered matrices\n"); 
          for(int i=0;i<m;i++){
              for(int j=0;j<m;j++){
              for(int k=0;k<m;k++){
              c[i][j]=c[i][j]+a[i][k]*b[j][k];
              }
          }
    }
           System.out.print("Product of matrix is:\n"); 
            for (int i = 0; i < m; i++)
        {
            for (int j = 0; j < m; j++)
            {
                System.out.print(c[i][j] + " ");
            }
            System.out.println();
        }
            input.close();
            return(c);
            
    }
    
}



